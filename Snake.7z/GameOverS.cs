﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameOverS : MonoBehaviour 
{
    public float delay = 3;

    public IEnumerator Start()
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene("snake1");
    }
}
